<?php
 define('HOST','localhost');
 define('USER','id12777779_root2');
 define('PASS','F@HSO_pbO3L?\Mmc');
 define('DB','id12777779_restoran');

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');